#include "apc.h"

int main(int argc, char *argv[])
{
    node *head1 = NULL, *tail1 = NULL, *head2 = NULL, *tail2 = NULL, *headR = NULL, *tailR = NULL;


    // Validation
	if(cla_validation(argc,argv)==FAILURE){
		printf("Error : Usage - ./a.out <oprand1> <operator> <operand2>\n");	
		return FAILURE;
	}

    // Create 2 lists 	of operands

	create_list(argv[1],&head1,&tail1);
	create_list(argv[3],&head2,&tail2);


    // Remove pre zeros

    char oper = argv[2][0];

    switch(oper)
    {
	case '+':
	    addition(tail1, tail2, &headR, &tailR);
		print_list(headR);
	    break;

	case '-':
		int oder=compare_list(head1,head2);
		if(oder==1){
			subtraction(tail1,tail2,&headR,&tailR);
		}
		if(oder==2){
			printf("-");
			subtraction(tail2,tail1,&headR,&tailR);
		}
		if(oder==0){
			insert_last(&headR,&tailR,0);
			print_list(headR);
		}
	    break;

	case 'x':
		multiplication(tail1,tail2,&headR,&tailR);
		remove_pre_zeros(&headR);
		print_list(headR);
		break;;
	case 'X':
		multiplication(tail1,tail2,&headR,&tailR);
		remove_pre_zeros(&headR);
		print_list(headR);
	    break;

	case '/':
	    break;

	default:
	    printf("Invalid operator\n");
    }
}

